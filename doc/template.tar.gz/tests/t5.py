
def f(a, b):
    return 2*a + 3*b
