
def f(x):
    if x > 0:
        return 3 * x
    return 2 * x

def f_inv(x):
    if x > 0:
        return x / unknown_int()
    return x / unknown_int()
