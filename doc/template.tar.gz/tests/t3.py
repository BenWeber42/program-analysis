def f(x, y):
    return x + y + 1, x

def f_inv (p, q) :
    return unknown_choice(p,q) , unknown_choice(p,q) + unknown_choice(p,q,-p,-q) + unknown_int()